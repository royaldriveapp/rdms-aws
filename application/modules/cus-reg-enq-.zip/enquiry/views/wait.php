<div class="right_col" role="main">
     <div class="clearfix"></div>
     <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
               <div class="col-middle">
                    <div class="text-center text-center">
                         <h1 class="error-number">Maintenance</h1>
                         <h2>Please wait...</h2>
                         <p>You can't create new enquiry, we will be performing important server maintenance in a few hours</p>
                    </div>
               </div>
          </div>
     </div>
</div>