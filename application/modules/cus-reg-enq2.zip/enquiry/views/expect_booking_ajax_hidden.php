<input type="text" value="<?php echo $enq_entry_date ?>">
